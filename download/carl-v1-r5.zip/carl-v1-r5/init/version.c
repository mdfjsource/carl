// SPDX-License-Identifier: GPL-2.0-only
// Copyright (c) 2026 Mau


/* Dats the kernel */

const char *kernel_name = "Carl";
const char *kernel_version = "1.1";
const char *kernel_author = "Mau";
const char *kernel_organization = "MDFJ";

const char *kernel_build = __DATE__" "__TIME__;

