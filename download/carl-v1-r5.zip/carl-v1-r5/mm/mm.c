// SPDX-License-Identifier: GPL-2.0-only
// Co-authored-by: Claude <noreply@anthropic.com>

#include <carl/mm.h>
#include <carl/carl.h>

#define CARL_MM_IMPLEMENTATION 0x022
#define CARL_MM_IMPLEMENTATION_VERSION 0x022


extern void printc(const char *msg);

/* ---------------------------------------------------------------------
 * Heap configuration
 * ------------------------------------------------------------------- */

/*
 * Size of carl_mm's static heap. This is a reasonable placeholder for
 * an early-stage kernel without a page allocator yet. Override via
 * -DCARL_MM_HEAP_SIZE=N at build time if a different size is needed.
 */
#ifndef CARL_MM_HEAP_SIZE
#define CARL_MM_HEAP_SIZE (1024u * 1024u) /* 1 MiB */
#endif

/* Minimum alignment for every block returned to the caller. Must be a
 * power of two: the align-up calculation depends on that. */
#define CARL_MM_ALIGN sizeof(void *)

/* Magic numbers used to distinguish live blocks from freed blocks, and
 * to detect corruption / invalid pointers / double frees. */
#define CARL_MM_MAGIC_ALIVE 0xCA12A11Eu /* "carl alive" */
#define CARL_MM_MAGIC_FREED 0xDEADCA12u /* "dead carl" */

/* ---------------------------------------------------------------------
 * Internal structures
 * ------------------------------------------------------------------- */

struct carl_mm_block {
	unsigned int magic;          /* CARL_MM_MAGIC_ALIVE / _FREED */
	size_t size;                 /* usable size (excludes this header) */
	struct carl_mm_block *next;  /* next block in the free list,
				       * kept in ascending physical address
				       * order. Only meaningful while the
				       * block is free. */
};

#define CARL_MM_BLOCK_HDR_SIZE sizeof(struct carl_mm_block)

/* Backing static heap. Lives in .bss until a real page allocator
 * exists (pending, see project roadmap). */
static unsigned char carl_heap[CARL_MM_HEAP_SIZE];

/* Free list, kept sorted by ascending memory address. This ordering is
 * what makes O(1) coalescing with direct neighbors possible on insert
 * (no need to search for "who is physically adjacent", just look at
 * prev/next in the list). */
static struct carl_mm_block *carl_free_list;

/* Becomes 1 the first time the heap gets initialized. */
static int carl_mm_initialized;

/* ---------------------------------------------------------------------
 * Internal helpers
 * ------------------------------------------------------------------- */

/*
 * Aligns n up to CARL_MM_ALIGN. Returns 0 if the rounding would
 * overflow size_t (caller must treat 0 as failure for n != 0).
 */
static size_t carl_mm_align_up(size_t n)
{
	size_t aligned;

	if (n > (size_t)-1 - (CARL_MM_ALIGN - 1))
		return 0; /* overflow: cannot align without wrapping */

	aligned = (n + (CARL_MM_ALIGN - 1)) & ~(CARL_MM_ALIGN - 1);
	return aligned;
}

static void carl_mm_init(void)
{
	struct carl_mm_block *initial;

	if (carl_mm_initialized)
		return;

	initial = (struct carl_mm_block *)carl_heap;
	initial->magic = CARL_MM_MAGIC_FREED;
	initial->size = CARL_MM_HEAP_SIZE - CARL_MM_BLOCK_HDR_SIZE;
	initial->next = NULL;

	carl_free_list = initial;
	carl_mm_initialized = 1;
}

/* True if "blk" looks like a plausible header: inside the heap and
 * with a size that does not exceed the heap bounds. This does not
 * replace the magic check, it is an extra layer against corruption. */
static int carl_mm_block_size_plausible(struct carl_mm_block *blk)
{
	unsigned char *blk_addr = (unsigned char *)blk;
	unsigned char *heap_end = carl_heap + CARL_MM_HEAP_SIZE;
	unsigned char *user_data = blk_addr + CARL_MM_BLOCK_HDR_SIZE;

	if (blk->size > (size_t)(heap_end - user_data))
		return 0;

	return 1;
}

/* Returns the block header for a given user pointer, validating that
 * the pointer actually falls within the heap, that its magic is
 * consistent, and that its declared size is physically possible.
 * Returns NULL if anything is off (and already reported why via
 * printc). */
static struct carl_mm_block *carl_mm_block_from_ptr(void *ptr)
{
	struct carl_mm_block *blk;
	unsigned char *raw = (unsigned char *)ptr;
	unsigned char *heap_end = carl_heap + CARL_MM_HEAP_SIZE;

	if (!ptr)
		return NULL;

	if (raw < carl_heap + CARL_MM_BLOCK_HDR_SIZE || raw > heap_end) {
		printc("carl_mm: pointer outside heap range\n");
		return NULL;
	}

	blk = (struct carl_mm_block *)(raw - CARL_MM_BLOCK_HDR_SIZE);

	if (blk->magic == CARL_MM_MAGIC_FREED) {
		printc("carl_mm: double free detected\n");
		return NULL;
	}

	if (blk->magic != CARL_MM_MAGIC_ALIVE) {
		printc("carl_mm: invalid or corrupted pointer\n");
		return NULL;
	}

	if (!carl_mm_block_size_plausible(blk)) {
		printc("carl_mm: corrupted block size detected\n");
		return NULL;
	}

	return blk;
}

/* Finds the first free block that fits "size" usable bytes (first-fit).
 * Returns the block and, via output parameter, the address of the
 * "next" pointer that references it (either the list head or the
 * predecessor's next), so it can be unlinked without needing a
 * doubly-linked list. */
static struct carl_mm_block *carl_mm_find_fit(size_t size,
					       struct carl_mm_block ***link_out)
{
	struct carl_mm_block **cursor = &carl_free_list;

	while (*cursor) {
		if ((*cursor)->size >= size) {
			*link_out = cursor;
			return *cursor;
		}
		cursor = &(*cursor)->next;
	}

	return NULL;
}

/* If the found block is larger than necessary, splits it in two: one
 * of the exact requested size, and a remainder that stays in the same
 * free-list slot via blk->next. */
static void carl_mm_split(struct carl_mm_block *blk, size_t size)
{
	size_t remaining;
	struct carl_mm_block *rem;

	remaining = blk->size - size;

	/* Only worth splitting if the remainder fits another full
	 * header plus at least CARL_MM_ALIGN usable bytes. */
	if (remaining < CARL_MM_BLOCK_HDR_SIZE + CARL_MM_ALIGN)
		return;

	rem = (struct carl_mm_block *)((unsigned char *)blk +
					CARL_MM_BLOCK_HDR_SIZE + size);
	rem->magic = CARL_MM_MAGIC_FREED;
	rem->size = remaining - CARL_MM_BLOCK_HDR_SIZE;
	rem->next = blk->next;

	blk->next = rem;
	blk->size = size;
}

/* Inserts "blk" (just freed) into the free list keeping it sorted by
 * physical address, and merges it with the previous and/or next
 * neighbor if they are physically adjacent. This is what prevents the
 * heap from fragmenting under normal use. */
static void carl_mm_insert_and_coalesce(struct carl_mm_block *blk)
{
	struct carl_mm_block **cursor = &carl_free_list;
	struct carl_mm_block *next;
	unsigned char *blk_end;

	/* Find the insertion point: the first free block whose address
	 * is greater than blk's. */
	while (*cursor && (unsigned char *)*cursor < (unsigned char *)blk)
		cursor = &(*cursor)->next;

	next = *cursor;
	blk->next = next;
	*cursor = blk;

	/* Try to merge blk with next (its physical successor in the
	 * free list, if they are contiguous in memory). */
	blk_end = (unsigned char *)blk + CARL_MM_BLOCK_HDR_SIZE + blk->size;
	if (next && blk_end == (unsigned char *)next) {
		blk->size += CARL_MM_BLOCK_HDR_SIZE + next->size;
		blk->next = next->next;
	}

	/* Try to merge the predecessor (if any) with blk. cursor still
	 * points at the link that now holds blk, so finding the actual
	 * predecessor requires walking from the start again -- the free
	 * list is intentionally not doubly linked to keep the header
	 * small, so this extra walk is the accepted cost for that
	 * memory savings. */
	if (carl_free_list != blk) {
		struct carl_mm_block *prev = carl_free_list;

		while (prev->next != blk)
			prev = prev->next;

		blk_end = (unsigned char *)prev + CARL_MM_BLOCK_HDR_SIZE +
			  prev->size;
		if (blk_end == (unsigned char *)blk) {
			prev->size += CARL_MM_BLOCK_HDR_SIZE + blk->size;
			prev->next = blk->next;
		}
	}
}

/* ---------------------------------------------------------------------
 * Public API
 * ------------------------------------------------------------------- */

void *carl_malloc(size_t size)
{
	struct carl_mm_block *blk;
	struct carl_mm_block **link;
	size_t aligned;

	if (size == 0)
		return NULL;

	aligned = carl_mm_align_up(size);
	if (aligned == 0) {
		/* size required rounding that overflows size_t. */
		printc("carl_mm: requested size overflows on alignment\n");
		return NULL;
	}

	/* Also check that header + aligned size does not overflow,
	 * before using it to search/split blocks. */
	if (aligned > (size_t)-1 - CARL_MM_BLOCK_HDR_SIZE) {
		printc("carl_mm: requested size too large\n");
		return NULL;
	}

	carl_mm_init();

	blk = carl_mm_find_fit(aligned, &link);
	if (!blk) {
		printc("carl_mm: out of memory\n");
		return NULL;
	}

	carl_mm_split(blk, aligned);

	/* Unlink from the free list. */
	*link = blk->next;

	blk->magic = CARL_MM_MAGIC_ALIVE;
	blk->next = NULL; /* unused while alive; keeps state clean */

	return (unsigned char *)blk + CARL_MM_BLOCK_HDR_SIZE;
}

void carl_free(void *ptr)
{
	struct carl_mm_block *blk;

	if (!ptr)
		return;

	blk = carl_mm_block_from_ptr(ptr);
	if (!blk)
		return; /* error already reported via printc */

	blk->magic = CARL_MM_MAGIC_FREED;
	carl_mm_insert_and_coalesce(blk);
}

void *carl_realloc(void *ptr, size_t size)
{
	struct carl_mm_block *blk;
	void *new_ptr;
	size_t copy_size;
	size_t aligned;

	if (!ptr)
		return carl_malloc(size);

	if (size == 0) {
		carl_free(ptr);
		return NULL;
	}

	blk = carl_mm_block_from_ptr(ptr);
	if (!blk)
		return NULL; /* invalid pointer: error already reported */

	aligned = carl_mm_align_up(size);
	if (aligned == 0) {
		printc("carl_mm: requested size overflows on alignment\n");
		return NULL;
	}

	/* Easy case: the current block already fits. We do not shrink
	 * it, to avoid unnecessary fragmentation from small reallocs. */
	if (blk->size >= aligned)
		return ptr;

	/*
	 * TODO(contributor): does not attempt to merge with the physical
	 * next neighbor even if it is free and the combined space would
	 * fit (which would avoid a copy). For now this always does
	 * malloc + copy + free, which is correct but not optimal. Good
	 * first issue for whoever wants to keep contributing to carl_mm.
	 */
	new_ptr = carl_malloc(size);
	if (!new_ptr)
		return NULL;

	copy_size = blk->size < aligned ? blk->size : aligned;
	{
		unsigned char *dst = (unsigned char *)new_ptr;
		unsigned char *src = (unsigned char *)ptr;
		size_t i;

		for (i = 0; i < copy_size; i++)
			dst[i] = src[i];
	}

	carl_free(ptr);
	return new_ptr;
}