// SPDX-License-Identifier: GPL-2.0-only
// Copyright (C) 2026-2028 Strawberry Team.

#ifndef RED_SOCKET_H
#define RED_SOCKET_H

#include <stddef.h>

#ifndef NETWORK_SOCKET_H
#define NETWORK_SOCKET_H

typedef int net_socket_t;

/* core API */
net_socket_t socket_create(int domain, int type, int protocol);
int socket_close(net_socket_t sock);

/* TCP */
int socket_connect(net_socket_t sock, const char *ip, int port);
int socket_bind(net_socket_t sock, const char *ip, int port);
int socket_listen(net_socket_t sock, int backlog);
net_socket_t socket_accept(net_socket_t sock);

/* data */
int socket_send(net_socket_t sock, const void *buffer, int length);
int socket_recv(net_socket_t sock, void *buffer, int length);

/* options */
int socket_set_option(net_socket_t sock, int option, const void *value);
int socket_get_option(net_socket_t sock, int option, void *value);

#endif 