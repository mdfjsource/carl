/* SPDX-License-Identifier: MPL-2.0 */
/* Copyright (c) 2026 Trovs DX */

#ifndef NE_START_H
#define NE_START_H

/**
 * @brief Bootstraps and initializes the core Ne driver subsystem.
 *        Orchestrates hardware thinking, validation, and engine dispatching.
 * @return 0 On successful initialization of the Intel graphics driver subsystem.
 *         1 If initialization fails or falls back due to non-Intel hardware architecture.
 */
int ne_start(void);

#endif /* NE_START_H */
