// SPDX-License-Identifier: MPL-2.0
// Copyright (c) 2026 Trovs DX

/* Static immutable table mapping Intel GPU PCI descriptors */
static const struct ne_pci_desc ne_intel_gpus[] = {

/* ========================================================================= */
/* Intel HD / UHD Graphics (Integrated GPUs)                                */
/* ========================================================================= */
    { INTEL_VENDOR_ID, 0x0042, NE_ANY_ID, NE_ANY_ID, NE_ARCH_GEN4_5,
      "Intel HD Graphics (Clarkdale)" },

    { INTEL_VENDOR_ID, 0x0046, NE_ANY_ID, NE_ANY_ID, NE_ARCH_GEN4_5,
      "Intel HD Graphics (Arrandale)" },

    { INTEL_VENDOR_ID, 0x0102, NE_ANY_ID, NE_ANY_ID, NE_ARCH_GEN6,
      "Intel HD Graphics 2000 (Sandy Bridge)" },

    { INTEL_VENDOR_ID, 0x0112, NE_ANY_ID, NE_ANY_ID, NE_ARCH_GEN6,
      "Intel HD Graphics 3000 (Sandy Bridge)" },

    { INTEL_VENDOR_ID, 0x0166, NE_ANY_ID, NE_ANY_ID, NE_ARCH_GEN7_75,
      "Intel HD Graphics 4000 (Ivy Bridge)" },

    { INTEL_VENDOR_ID, 0x0416, NE_ANY_ID, NE_ANY_ID, NE_ARCH_GEN7_75,
      "Intel HD Graphics 4600 (Haswell Mobile)" },

    { INTEL_VENDOR_ID, 0x1912, NE_ANY_ID, NE_ANY_ID, NE_ARCH_GEN9,
      "Intel HD Graphics 530 (Skylake)" },

    { INTEL_VENDOR_ID, 0x5912, NE_ANY_ID, NE_ANY_ID, NE_ARCH_GEN9,
      "Intel HD Graphics 630 (Kaby Lake)" },

    { INTEL_VENDOR_ID, 0x3E9B, NE_ANY_ID, NE_ANY_ID, NE_ARCH_GEN9,
      "Intel UHD Graphics 630 (Coffee Lake)" },

    { INTEL_VENDOR_ID, 0x9BC5, NE_ANY_ID, NE_ANY_ID, NE_ARCH_GEN9,
      "Intel UHD Graphics 630 (Comet Lake)" },

/* ========================================================================= */
/* Intel Iris / Iris Xe                                                      */
/* ========================================================================= */
    { INTEL_VENDOR_ID, 0x0D26, NE_ANY_ID, NE_ANY_ID, NE_ARCH_IRIS_LEG,
      "Intel Iris Pro 5200 (Haswell eDRAM)" },

    { INTEL_VENDOR_ID, 0x162B, NE_ANY_ID, NE_ANY_ID, NE_ARCH_IRIS_LEG,
      "Intel Iris 6100 (Broadwell)" },

    { INTEL_VENDOR_ID, 0x1926, NE_ANY_ID, NE_ANY_ID, NE_ARCH_IRIS_LEG,
      "Intel Iris 540 (Skylake)" },

    { INTEL_VENDOR_ID, 0x8A52, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE_LP,
      "Intel Iris Plus G7 (Ice Lake)" },

    { INTEL_VENDOR_ID, 0x9A49, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE_LP,
      "Intel Iris Xe (Tiger Lake)" },

    { INTEL_VENDOR_ID, 0x46A6, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE_LP,
      "Intel Iris Xe (Alder Lake)" },

/* ========================================================================= */
/* Intel Arc (Xe-HPG / Xe2)                                                  */
/* ========================================================================= */
    { INTEL_VENDOR_ID, 0x56A0, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE_HPG,
      "Intel Arc A770 Desktop" },

    { INTEL_VENDOR_ID, 0x56A1, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE_HPG,
      "Intel Arc A750 Desktop" },

    { INTEL_VENDOR_ID, 0x56A2, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE_HPG,
      "Intel Arc A580 Desktop" },

    { INTEL_VENDOR_ID, 0x56A5, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE_HPG,
      "Intel Arc A380 Desktop" },

    { INTEL_VENDOR_ID, 0x56A6, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE_HPG,
      "Intel Arc A310 Desktop" },

    /* Mobile variants */
    { INTEL_VENDOR_ID, 0x5690, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE_HPG,
      "Intel Arc A770M Mobile" },

    { INTEL_VENDOR_ID, 0x5691, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE_HPG,
      "Intel Arc A730M Mobile" },

    { INTEL_VENDOR_ID, 0x5693, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE_HPG,
      "Intel Arc A370M Mobile" },

    /* Embedded */
    { INTEL_VENDOR_ID, 0x56BE, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE_HPG,
      "Intel Arc A750E Embedded" },

    { INTEL_VENDOR_ID, 0x56BF, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE_HPG,
      "Intel Arc A580E Embedded" },

/* ========================================================================= */
/* Intel Arc Xe2 (Battlemage)                                                */
/* ========================================================================= */
    { INTEL_VENDOR_ID, 0xE202, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE2,
      "Intel Arc Xe2 (Core Ultra)" },

    { INTEL_VENDOR_ID, 0xE20B, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE2,
      "Intel Arc Xe2 (Dedicated GPU)" },

    { INTEL_VENDOR_ID, 0xE211, NE_ANY_ID, NE_ANY_ID, NE_ARCH_XE2,
      "Intel Arc Pro B60 (BMG-G31)" },

/* Sentinel */
    { 0, 0, 0, 0, 0, NULL }
};