/* SPDX-License-Identifier: MPL-2.0 */
/* Copyright (c) 2026 Trovs DX */

#ifndef NE_DETECT_H
#define NE_DETECT_H

/* Forward declaration to avoid pulling heavy structures into the header */
struct ne_pci_desc;

/**
 * @brief Scans the system bus and returns a compatible graphics unit.
 *
 * @return Pointer to a read-only hardware descriptor, or NULL if none is found.
 */
const struct ne_pci_desc *ne_detect_gpu(void);

/**
 * @brief Validates the CPU vendor and platform compatibility.
 *
 * @return 0 if Intel CPU is detected
 *         1 if non-Intel CPU is detected
 */
int ne_validate_cpu_vendor(void);

#endif /* NE_DETECT_H */